
import React from "react";

export default function MandateCorporationSite() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow-md p-6">
        <h1 className="text-3xl font-bold text-blue-700">Mandate Corporation</h1>
        <p className="text-gray-600">Tutoring • Academic Support • STEM Enrichment</p>
      </header>

      <section className="p-10 bg-gradient-to-r from-blue-600 to-green-500 text-white text-center rounded-b-3xl shadow-lg">
        <h2 className="text-4xl font-bold mb-4">Empowering Students for Success</h2>
        <p className="text-lg max-w-2xl mx-auto">
          High-quality tutoring, after-school programs, and STEM-focused enrichment designed to
          help students grow, learn, and excel.
        </p>
        <button className="mt-6 px-6 py-3 bg-white text-blue-700 rounded-2xl font-semibold shadow-md hover:scale-105 transition">
          Contact Us
        </button>
      </section>

      <section className="p-10 grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl shadow p-6">
          <h3 className="text-xl font-bold mb-2">Tutoring Services</h3>
          <p>K-12 reading, math, homework help, test prep, and academic growth.</p>
        </div>
        <div className="bg-white rounded-2xl shadow p-6">
          <h3 className="text-xl font-bold mb-2">After-School Programs</h3>
          <p>Structured homework support, enrichment activities, and skill-building.</p>
        </div>
        <div className="bg-white rounded-2xl shadow p-6">
          <h3 className="text-xl font-bold mb-2">STEM & Coding</h3>
          <p>Beginner coding, robotics, and computer science fundamentals.</p>
        </div>
      </section>

      <section className="p-10 bg-white shadow-inner">
        <h2 className="text-3xl font-bold text-center mb-6">About Mandate Corporation</h2>
        <p className="max-w-3xl mx-auto text-center text-gray-700">
          Mandate Corporation provides professional, curriculum-aligned academic support for
          students and organizations. With expertise in tutoring, classroom management, and STEM
          enrichment, we help students reach their fullest potential.
        </p>
      </section>

      <section className="p-10 text-center">
        <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
        <p className="text-gray-700 mb-6">Email: info@mandatecorporation.com • Phone: (555) 555-5555</p>
        <button className="px-6 py-3 bg-blue-700 text-white rounded-2xl font-semibold shadow hover:bg-blue-800 transition">
          Send a Message
        </button>
      </section>

      <footer className="bg-gray-900 text-white p-6 text-center mt-10">
        <p>© 2026 Mandate Corporation. All rights reserved.</p>
      </footer>
    </div>
  );
}
